function changeText() {
    document.getElementById("greeting").innerHTML = ":)";
}